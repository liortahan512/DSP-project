function myDSPProject()
    %% שלב 1: טעינת קבצים
    [fileName, pathName] = uigetfile({'*.wav;*.mp3', 'Audio Files (*.wav, *.mp3)'}, 'Select an Audio File');
    if fileName == 0
        error('לא נבחר קובץ אודיו לעיבוד.');
    end
    filePath = fullfile(pathName, fileName);
    [sig, sampleRate] = audioread(filePath);

    %% שלב 2: המרה למונו
    sig = mean(sig, 2);

    %% שלב 3: חלוקת הסיגנל לחלונות
    windowDuration = 0.03; % 30ms
    windowSize = round(windowDuration * sampleRate);
    overlap = round(0.25 * windowSize);
    frameStep = windowSize - overlap;

    totalLength = length(sig);
    numFrames = floor((totalLength - overlap) / frameStep);

    frames = zeros(windowSize, numFrames);

    for i = 1:numFrames
        startIdx = (i - 1) * frameStep + 1;
        endIdx = min(startIdx + windowSize - 1, totalLength);
        currentFrame = sig(startIdx:endIdx);
        currentFrame = currentFrame .* hamming(length(currentFrame));
        frames(1:length(currentFrame), i) = currentFrame;
    end

    %% שלב 4: חישוב RMS וזיהוי פעילות קולית (VAD)
    frameRMS = sqrt(mean(frames.^2, 1));
    rmsThreshold = 0.3 * mean(frameRMS);
    vadBinary = frameRMS > rmsThreshold;
    vadTime = (0:numFrames - 1) * (frameStep / sampleRate);

    %% שלב 5: חישוב ספקטרוגרמה ופיץ'
    [S, F, T] = stft(sig, sampleRate, 'Window', hamming(windowSize), 'OverlapLength', overlap);
    S_db = mag2db(abs(S));

    pitchValues = pitch(sig, sampleRate, ...
                        'WindowLength', windowSize, ...
                        'OverlapLength', overlap, ...
                        'Range', [50, 500]);

    %% שלב 6: סינתזת אות פסאודו-דיבור
    synthesizedSignal = zeros(totalLength, 1); % אות הסינתזה
    for i = 1:numFrames
        if vadBinary(i) % רק חלונות עם פעילות קולית
            % מציאת התדרים ההרמוניים
            fundamentalFreq = pitchValues(i);
            if isnan(fundamentalFreq)
                continue; % אם אין פיץ', דלג על החלון
            end
            harmonicFreqs = (1:5) * fundamentalFreq; % חמשת ההרמוניות הראשונות
            harmonicFreqs(harmonicFreqs > sampleRate / 2) = []; % הסרת תדרים מעל Nyquist

            % יצירת ספקטרום סינתטי
            syntheticSpectrum = zeros(windowSize, 1);
            for freq = harmonicFreqs
                bin = round(freq / (sampleRate / windowSize)) + 1;
                if bin <= windowSize
                    syntheticSpectrum(bin) = 1; % אמפליטודה בהרמוניות
                end
            end

            % IFFT כדי לשחזר את האות
            syntheticFrame = real(ifft(syntheticSpectrum, 'symmetric'));

            % שילוב האות הסינתטי באות הסופי
            startIdx = (i - 1) * frameStep + 1;
            endIdx = min(startIdx + windowSize - 1, totalLength);
            synthesizedSignal(startIdx:endIdx) = synthesizedSignal(startIdx:endIdx) + syntheticFrame(1:length(startIdx:endIdx));
        end
    end

    % חישוב תדר הבסיס מהספקטרום
baseFrequency = NaN(size(vadBinary)); % הכנה למשתנה תדר בסיס

for i = 1:length(vadBinary)
    if vadBinary(i) % רק חלונות עם פעילות קולית
        % מציאת התדירות של השיא הראשון בספקטרום
        [~, peakIndex] = max(abs(S(:, i))); % אמפליטודה מקסימלית בספקטרום
        baseFrequency(i) = F(peakIndex); % תדירות התואמת לשיא
    end
end


    %% שלב 7: הצגת תוצאות
    figure;

% גרף 1: גל הקול עם VAD
subplot(4, 1, 1);
timeAxis = (0:length(sig) - 1) / sampleRate;
plot(timeAxis, sig, 'b');
hold on;
stairs(vadTime, vadBinary * max(sig), 'r', 'LineWidth', 1.5);
title('Waveform with VAD');
xlabel('Time (s)');
ylabel('Amplitude');

% סינון הפיץ' לפי VAD
filteredPitch = pitchValues; % יצירת עותק של הפיץ'
filteredPitch(~vadBinary) = NaN; % הסתרת ערכי פיץ' באזורים ללא VAD

% חיתוך הספקטרוגרמה כך שתציג רק את התדרים החיוביים
positiveFreqIdx = F >= 0; % אינדקסים של תדרים חיוביים בלבד
F_positive = F(positiveFreqIdx); % תדרים חיוביים בלבד
S_positive = S_db(positiveFreqIdx, :); % ספקטרוגרמה מותאמת לתדרים חיוביים בלבד

% גרף 2: ספקטרוגרמה עם תדרים חיוביים בלבד
subplot(4, 1, 2);
imagesc(T, F_positive, S_positive);
axis xy;
colormap jet;
colorbar;
hold on;

% הוספת הפיץ' לספקטרוגרמה
plot(T(1:length(filteredPitch)), filteredPitch, 'g', 'LineWidth', 1.5);

% הוספת תדר בסיס לספקטרוגרמה
plot(T(1:length(baseFrequency)), baseFrequency, 'b', 'LineWidth', 1);

title('Spectrogram (Positive Frequencies Only) with Pitch and Base Frequency');
xlabel('Time (s)');
ylabel('Frequency (Hz)');

% הוספת הפיץ' לספקטרוגרמה רק באזורים עם VAD
filteredPitch = pitchValues;
filteredPitch(~vadBinary) = NaN; % מחיקת ערכים ללא VAD
plot(T(1:length(filteredPitch)), filteredPitch, 'g', 'LineWidth', 1.5);

% הוספת תדר בסיס (הכחול)
baseFrequency = filteredPitch / 2; % דוגמה לתדר בסיס כחצי מהפיץ'
plot(T(1:length(baseFrequency)), baseFrequency, 'b', 'LineWidth', 1);

title('Spectrogram with Pitch and Base Frequency');
xlabel('Time (s)');
ylabel('Frequency (Hz)');

% גרף 3: קונטור הפיץ'
subplot(4, 1, 3);
pitchTime = T(1:length(filteredPitch));
plot(pitchTime, filteredPitch, 'g', 'LineWidth', 1.5); % פיץ' מסונן
hold on;
plot(pitchTime, baseFrequency, 'b', 'LineWidth', 1.5); % תדר בסיס מסונן
title('Pitch and Base Frequency Contour (VAD Only)');
xlabel('Time (s)');
ylabel('Frequency (Hz)');
ylim([50, 500]);
legend('Pitch', 'Base Frequency');

% גרף 4: אות סינתטי
subplot(4, 1, 4);
timeAxisSynth = (0:length(synthesizedSignal) - 1) / sampleRate;
plot(timeAxisSynth, synthesizedSignal, 'm');
title('Synthesized Pseudo-Speech Signal');
xlabel('Time (s)');
ylabel('Amplitude');

disp('Filtered Pitch:');
disp(filteredPitch);

disp('Base Frequency:');
disp(baseFrequency);


    %% שלב 8: ייצוא התוצאות
    writetable(table(vadTime', vadBinary', 'VariableNames', {'Time', 'VAD'}), 'vad_results.csv');
    writetable(table(T', pitchValues(1:length(T))', 'VariableNames', {'Time', 'PitchFrequency'}), 'pitch_results.csv');
    audiowrite('synthesized_signal.wav', synthesizedSignal, sampleRate);
    fprintf('תוצאות נשמרו בקבצים vad_results.csv, pitch_results.csv, synthesized_signal.wav\n');

% ייצוא האות הסינתטי לקובץ WAV
%audiowrite('synthesized_signal.wav', synthesizedSignal, sampleRate);
%disp('Synthesized signal has been saved as "synthesized_signal.wav".');



end


